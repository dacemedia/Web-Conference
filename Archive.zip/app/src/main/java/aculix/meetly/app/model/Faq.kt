package aculix.meetly.app.model

data class Faq(
    val id: Int,
    val title: String,
    val description: String
)